class Recruiter < ApplicationRecord
    has_many :groups
end
