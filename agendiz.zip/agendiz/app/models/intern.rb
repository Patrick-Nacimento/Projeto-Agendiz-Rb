class Intern < ApplicationRecord
    belongs_to :group
end
