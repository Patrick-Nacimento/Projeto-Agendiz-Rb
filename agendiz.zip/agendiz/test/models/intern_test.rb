require 'test_helper'

class InternTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
