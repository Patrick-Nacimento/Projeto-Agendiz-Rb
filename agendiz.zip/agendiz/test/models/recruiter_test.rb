require 'test_helper'

class RecruiterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
